package jdbc2_DAO1.dao;

public class OrderDAOImpl extends BaseDAO implements OrderDAO {

}
