package jdbc2_DAO1.dao;

public interface OrderDAO {

}
